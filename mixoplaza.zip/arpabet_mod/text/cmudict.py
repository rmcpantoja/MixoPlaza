""" from https://github.com/keithito/tacotron """

# FRENCH MODIFICATION

import re
import pyopenjtalk


# https://en.wikipedia.org/wiki/ARPABET
valid_symbols = [
    'AA', 'AA0', 'AA1', 'AA2', 'AE', 'AE0', 'AE1', 'AE2', 'AH', 'AH0', 'AH1', 'AH2',
    'AO', 'AO0', 'AO1', 'AO2', 'AW', 'AW0', 'AW1', 'AW2', 'AY', 'AY0', 'AY1', 'AY2',
    'B', 'CH', 'D', 'DH', 'EH', 'EH0', 'EH1', 'EH2', 'ER', 'ER0', 'ER1', 'ER2', 'EY',
    'EY0', 'EY1', 'EY2', 'F', 'G', 'HH', 'IH', 'IH0', 'IH1', 'IH2', 'IY', 'IY0', 'IY1',
    'IY2', 'JH', 'K', 'L', 'M', 'N', 'NG', 'OW', 'OW0', 'OW1', 'OW2', 'OY', 'OY0',
    'OY1', 'OY2', 'P', 'R', 'S', 'SH', 'T', 'TH', 'UH', 'UH0', 'UH1', 'UH2', 'UW',
    'UW0', 'UW1', 'UW2', 'V', 'W', 'Y', "Z", "ZH"
]


# IPA to ARPABET

replacements = {
    'a': 'AA0',
    'e': 'EH0',
    'i': 'IY0',
    'o': 'OW0',
    'u': 'UW0',

    'b': 'B',
    'v': 'V',
    'k': 'K',
    'd': 'D',
    'f': 'F',
    'h': 'HH',
    'm': 'M',
    'n': 'N',
    'ny': 'NG',
    's': 'S',
    'sh': 'SH',
    't': 'T',
    'w': 'UW',
    'y': 'Y',
    'ch': 'CH',
    'g':'G',
    'p': 'P',
    'r': 'R',
    'j': 'Z',
    'z': 'ZH',
    'ts': 'T S',
    'cl': "K L",
    "pau": "P AA0 UW0"
}


_valid_symbol_set = set(valid_symbols)

def is_romaji(word):
    words_regex = r"[\u3000-\u303f\u3040-\u309f\u30a0-\u30ff\uff00-\uff9f\u4e00-\u9faf\u3400-\u4dbf]+"
    return len(re.findall(words_regex, word)) == 0


class CMUDict:
    '''Thin wrapper around CMUDict data. http://www.speech.cs.cmu.edu/cgi-bin/cmudict'''

    def __init__(self):
        self.backend = pyopenjtalk.g2p

    def grapheme2romaji(self, word):
        return self.backend(word).lower()

    def romaji2arpabet(self, romaji_word):
        arpabet_word = ""
        for c in romaji_word.split():
            if c in replacements:
                replacement = replacements[c]
                arpabet_word += replacement + " "
            elif len(c) == 2 and c.endswith("y") and c[0] in replacements:
                replacement = replacements[c[0]]
                arpabet_word += replacement + "IY0 "
            else:
                raise Exception(f"ERROR: The word {romaji_word}, '{c}' is not in the replacements list.")                
        return "{" + arpabet_word.strip() + "}"


    def word2phonemes(self, word):
        word = self.grapheme2romaji(word)
        return self.romaji2arpabet(word)

    def __len__(self):
        return len(self._entries)

    def lookup(self, word):
        '''Converts word to adapted ARPAbet'''

        # Apply it only on words, keep punctuation unchanged
        #words_regex = r"[\u30A0-\u30FF\u3040-\u309FーA-Za-zÀ-ÿ'’]+"
        words_regex = r"[\u3000-\u303f\u3040-\u309f\u30a0-\u30ff\uff00-\uff9f\u4e00-\u9faf\u3400-\u4dbfA-Za-zÀ-ÿ'’]+"
        for match in re.findall(words_regex, word):
            word = word.replace(match, self.word2phonemes(match), 1)

        return word